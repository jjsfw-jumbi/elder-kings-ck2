A tool used for automatically assigning the immortal_age property to long-lived races when they reach their _2 trait at age 56.

INSTRUCTIONS
1. File -> Open Files... and select the character history file you would like to apply the immortal_age property to. Multi-file selection is supported. The left box will fill with all character ids of characters who are at least 56 and do not already have the immortal_age flag from the selected file. Clicking on an id will list its birth and death dates, as well as their age when they died.
2. Select characters you wish to add the immortal_age tag to and press the "Add Age to Selected Button".
2a. Alternatively, select characters you do NOT wish to add the tag to (if any) and press the "Don't Add to Selected" button to remove them and then press the "Add Age to All" button.
2 - the sequel. The textbox and radio buttons to the right can be used to selectively include/exclude characters by religion and culture.
3. Press the "Write Output Files" button. This will create copies of the culture files selected in step 1. modified to have the characters selected in 2./2a. have their appropriate immortal_age tag.
4. Replace the original history files with the output files.
5. Wheek wheek wheek wheek wheek wheek wheek wheek wheek wheek rumblestrut wheek wheek wheek wheek wheek wheek.                                                                                      
                                                                                                                                                                                                        
                                                                                                               ``    ````                                                                               
                                                                                                   ````....-.----...---:..-..````                                                                       
                                                                                             ``````...-----............-.....-:///:-----.``                                                             
                                                                                        ```.-....```...-.--.........::::-:::-:+shyhyyyyyyo/-...``                                                       
                                                                                   ``...........``.....--:::------..-//+o//++sohmhdhdhhhhhhyhyso/-.``                                                   
                                                                                `.-::-................--:::///:/:::-:/++os+oosyymdmddhhhdmmddddhhyyso:`                                                 
                                                                             ``.:--....``.......-------::////+++++////+sooooyoohhmdhdhdddddhhhddddhhhho:.                                               
                                                                           `.-:::--...`......---:::////://///+oosoo+oooyssssyysyshyyhhhhhhhhhhddddhhhhhy+/.                                             
                                                                         `.:::--.........--::://+++++++osooooosyyyyyyhyyyhysyyysssyyyyyhddddhyddhhhhhhhhyo/.                                            
                                                                       `.:/:-..........--::///+++ooo+++oossssyyyyhhhhhhhyyhyysssyoysyhhmmddhhdddhhhhhhyyhyso/-.`                                        
                                                                     `.::---...`.....-::////+++++++o+/++++oo+sssyyhhdmdddhssyssoyoyshhmmmddmdhdmhhyyhysshssyso/+--.---..``                              
                                                                   ``.-----..``..--::///+++++++++///++//+/+o+osyssshdmddhyyo+osossyydddmddddmddddhyyysoyyoyyy+sysooso+oo/-.                             
                                                                  .:::::-..```.-:://///////++////+/:++///+++o+sssysoyhdhyysso//ossyhdmmNmdmdmmdddhdhhossoohhoydhhyyy++/-.```                            
                                                                `-:::::-.```.--:://////////+///+/++/:+++++o+o++syyyy+oydhs+/////sydhhdmmmmdhmmddmhdyyyssosyssyddysyosss++/:.``                          
                                                             `.-//::-:-.```..--::://///////////+++++//++oosysoosyhsys+oydho/---/oyhdyhdmdmmmddmdmhydyysyosshshdssyhhdhhso:.`                            
                                                          `.-:/:::----.``.....-::://///////+/+/+o+++oo+ooyyyhhyssdshyosohdy+:...:+oshoodddmmhddddhhdhssosodyyhssymddhhddhso/-`                          
                                                        `-////:----:-.``....-://////+////+//++oo+soossoosohyhhhsyyhsyyshhdy/:-.`..--y+o/hyhdhdhmhhdddyyosydsssyhddhdddddhhhhs+:`                        
                                                     `.-///::---:---.....-:/+ooo++o+++++/++/+ooosoyyhyosyyhhyyyysoy+yhydmy/-...``...-+::-/yyyhddddmdyyyyhhhsshyhddddhddddhhdddho.                       
                                                `....-::///::----:----:/++++oooooooso++oooo+oosoosooyhyhyhdhhysyhs+osdhmd+:......`....----:yshdhhdmhsysshhyshyddddddddddhhhhddhhy/`                     
                                             `--:-.-:/::::::--::::+ooooooooooooooosooooooossssssyyysyhdhdydddhsyhs/oyddho::.......```..-.-`/+ohhydddhsoyyyydohdhhhhhhhyhyyyhddddhhs.                    
                                          `-----.--://--:://:-:::osyyyyyyyyyyyyyyyhhyyysssyyyysyyyssyshhmyhddhhhyyosdddo::-.......```..`...`:/ydshhyhosyyoyhshddhsyhdhhhhhhdddmmddhs.                   
                                       `--:-...-::-:::/:/:---:///ossssssssyyyyhhhhhhhhyyyyyyyyysoyhhsddhhdhyyyyysyhhdhh+:--......```..``.`.`--shsysyysyyysydhhhhyshhhhhhhyyyyyyyhddddooo/:.             
                                     `/+/:-..--:/:::::::::/+oooss+o+ossooossyyyyyyyyyyyyyyyyyyyhhyyhyhhhhyhdhhhhydddhss+---.`.....``..`````...osyssyssysysdhyyyhydddhyyyyhhyhyyyhhhhdhosoo+-            
                                   .-+/:-..-::////:://::/osyyyyyy///++++osssssyyyyyyhhhyhhhyyyhyyhhhhyhssyyyhyhhdhdss+++:---.`....`...``.```..:/o+syssyssysssyhdyhdhyhdddhddddddddddmdooo+:``           
                                 ./+/:-..-://///:://////+oyyhhhyso//+++oossssyyyyyyhhdhhhhhdhddddhdddhyhyyhyyyyhdhs+/+/:---...`.......```````..-:+yossssoooosyyshhyyyhhhhdhhdddddddmmh++/-              
                               ./+/::...://///////////////+shhys+:-//++oosyyhhhdhhhddddhhdddddddmdhddhhhhhyyysyhdhs/::/:---...`....`.````````.`.-//ossso+oosssyyyyyhyhdmmmdhhdhdddddds/.`               
                             `:oo:--..-:////////////////++++oso/:://+osydmmmmdddhhddddddddhhhdddmddddhyyyhyyyyyhhhyo/:-:---.......``.`````````.`.-:++ooo+ooooyysyyyyhhdddddhyyyo/.-::/-`                
                            -ooo+-....:////////////:::/+++++o+++++shhddddddddddhddddmmmddhhdddhhhdddhhhyhhhhhyyhhhys+/:-----.....`.`.````.``````..-:/ooosoosssyyyyhhhdddddhys+/-``                      
                          .+so//-.``.://///:////::::/+oooooooooossyyhddddddddhhhhhhdhdddddhhhhdhhddhhhhhddddddhyyhhso+/:----.....`.``````````````..:/+osysssoosyyyhhhhddhhyso+/:-.`                     
                        `:shy+-.-...:/://::://///:--:+oossssosssssssyyhhhhddhhhhhyhyhhhhhhhhhhyydddddddmmNNNNNmhyhhyso+/:---.....``.`````````````..-:+shmmdssosyyyyyyyhhhhhyy+++/-`                     
                       .shys+:...`.://///:-:://::---:++oossssssssssossssyyyyyyyyyyyyyyyyyyyhhhhhhhddmmmNNNNNNNNmyyhysso+:--.-...```````.```````````-:/smmmmdhyyyyyhhhhddddhyyo+///:.                    
                     `+yhs+:-..```-::/:::::::::----:/++oossssssssssssssosssyyyyyyyyyysssssssyyyyhhdmNmNmmNNNNNNmhyyyssyo::..-....`````..```````````.-/odmNNNNdyshyhdhhhhdhhhyso+///:`                   
                    -shys+:-..```.::::::::::/::-.-:/++oooosssssssooo+oo+++osyyyyyyyyyssssssssyyyyhhmmNNNNmmmNNNmdyysssso/-.......`````.`````````````.-+dddmmNNdsyshyyyhhddhhhso+///:-`                  
                  `+yyso/--.````.-:://////:::-...-/++ooooooooooo+++++o+ooooosssssssssyyysssyyyyyhhdNmNNNNyshNmmmdhysssso/-........````````````````````-ydo::dNNssyhyyyyhddddddhs+////-`                 
                 .ohhs+:-...```.-:::////////-....:/++o+ooooo+++++oooo+oooooooooossssyyyhhyhyhhhhhhmNNNNNNNmNNdmmddyssss+/:-.....`.````````````````````./h/+ymNNdsyyyhhhddddddddhyo////.`                
                -shhyo::-......-:://///////--....://++oooo+++o+ooo+++ooo++ossssyyhhhhhdddhhhdhhhhhmNNNNNNNNNNmmmmhsssss+/:-.......`````````````````````./+ydmNNdyssyyyhhhdddmmddhyo+//:.`               
               -yddhys+:-....-:::::///////:--....:///+++oooooo+o+++osoo+oosyhyyhhhhhdddhhdhhhhhhhhmNNNNNNNNNmmmmdssssoo//:-....`.``````````````````````.-:osmmNmyyoyyhhdddddddmmdhs+//:-`.``            
              :yhhhhho/:-....-/://////////:-.....://+++++++++++++ooooooosooyyhhhhddddhhhyyyyyyhhhhhdmNNNNNNmmmmyysosoo+/:--....``````````````````````````-:shmmmsysyyhddddhddddmddyo+//:.-/-`           
             -yhhhhhhs+/-...-::///////////:-...--////+++///+++++oooooosssyysyyhhyyyyyyysyyyyyyyyyssyhmmmmmmmmdysoooo++/:::......`````````````````````````.-/sdmhsysssshddddddmddhdhso//:..//:.          
            .syyhdhyhyo/--..::://////////:-....-//:://///+oooooooosssssssooosssssyssssssssyyssssyyyyyyyhhdhhysoo++++//:----......````````````````````````.--+sysyyssssyhyhddmddhhhhyso/::.-//:.         
           `ohhhdhhhso/-....::///:://////:--...-::://///++o++oooossooooo+o+sooooooooooosyyyyyssyyyssyyysssoooooo+++/:--..-......``````````````````````````.-:+sysossyyyyyhhddddhhhyhyso/:-.://:`        
          `ohddhhhso+:-....-:////////////:-....-::/++++/+++++oooooooo++oo+/+/+++++osoyyyhyyyyysssssooooooooooooo+///:--...`....`.``````````````````````````.:+ohhhhhhhdhddddhhdhhddhyo//--.::::-        
         `/hdhhysss/--..``.-:://////+++//:-...--://////+ooooooossooo+oooooooo/++ooyyyhyhyssooooooooooooooosoooo+/:::---....`...`.```````````````````````````:++syhhhhhhdhddhdddddyhhs+/::---:/:-`       
        `/oyshhhyo/:-..`...:::/++//++++//::...:://++ooo+o+oo++ooo+ossssso++o++ossssssysosooooooooooooooosssooo++//----.....``..``..`.```````````````````````-:/ysyyhyyyhhhhhdddhhhhhs+//::--:/::.       
       `/syshdhhs/:-...`...-:::/+/+//o////:--.-:///++++oo++++oooosssoo+ooossooosyyysyyssssooo+oosoosooooooooooo//::-.-..-.......`..``..`````````````````````.-/+osyyhdhhhdhyyhdddhhyo++//:--::::-`      
       :ossdmddys+/...`....-://////+++////:-..--/+++++o+oooooooooo++o+oosooo+osyyysosssso+oooooooosssssooo++o++//:---.-...--..``...``..`````````````````````..-:ossyhyyysyhhhydddmhhyo////:--::::-      
      `/oyhdddyyy/-......`.:///////+++//+/:-...-//++++++oooooo++++ooosooossyyyssssosoooooooooooosoossooooo++/:::--:-----....-.......`..``````````````````````.:-/+ssosyhhddddhdmhddyys+//::--::::-`     
      -syhddhhhh+:::--....://///////+/++//-.....://+++ooo++++oooosssossssyyssssss+osssoooooooooosssoosso+++//::----:------....-.........`````````````````````..-/+/:+syhyhdhhhhddhdhyhs+:::---:::-`     
     `shhhhdddhssyho/::-..-::://///++//+/:-....--::///++oosososssossssssso+oosssoso++/++++oooossssssooooo+//:--------...-..---.-...-....````````````````````.......:osshhhdhyhhdddhhhyyo//::--:::-`     
     -shhhhhhhhhhds+/:/:..:://////+++/+o//:....--://++o+++oosssoossysysssssysssoooo+++o+++ooooooooosoo++++//----------.....-----..---.-..````````````````.....```..-:/oosyhhyhdhdhdhhys+///:-:/::-`     
    `+yhhdhdddddhyyo/+/-..::/:///+o+++++/+:....-::/+++ooosssoooossssosyssysssoooo++++++/+oooooosssooooo+//::/:---....-.-----------:--:-..````.`````.``........````.-:/+ossyhyyhydhdhmhs+//:--://::.     
    -yyhhddddddddho+o/:-..-::///++++oo+///-....--://+++ooooossossssssssyysooooooo++++oooooooooooooooooo+++/::::::---....----::/:-:/-./-....`..````...........``...-:/ooyyyyyyyhhhdhhdhs//::::::/:-`     
   `/oyyddmdhhddhsosoo+-...:://////+++//+/:...--::/+++++oooooossssysssssossoooo+++++++oo++++ooooooo++++++++/:::::-----------:///::/:-:--.-...`......-...........-:/oyhhhyyhhyyhdyhhhhys+/::::://:-.     
   `+yhhddddhddhyyhho:..`.-::::///+++/+ss:-...-::://+oooooooosssssssyyssooosoooooo+++/+++/++o++++++++////+++::::::::-------:://///+::----./-........--..........-/+ooosyhhyyssyhhhhyhs++//:::://::.     
   -shhhhhddddyydhy+:..``.---:://+o/+/sso:....-::::/+++ooosoosssssssyssoossoooo++++//++++++++++oo+++//++//:-----------::-::://///////::/--/-.....-----.............-:/+oosysoosshyssso+/:/:/::///:.`    
   :syhhyhddddyhyo+:-..``..--::/+oo+++oo/-....--::://+ooooooosyyssysoooosssooooooooo+ooo+ooosoooo+oooooooo++/::------::::://+++/+o+/////:/:-------:-----...........-:+syyyyysssyyhhsoo+//:::::/:/:.     
   -+yhdddhddyhyo+/--.```...-::/+o++++o+/-....-::::///+o++osssssssosoooyyssssooooo+++oo+oosso++oooooooo+++/:-----:------.--:+ossssssoo++//o//::://///:--....````.....:/+oyhsssyyyyhyo/////::::/:::.     
   .+ydddhhdhhys++-:-.``....--::+o+++/++/:...-:/:::////++ooossoooosoosyyysyyssso++++ooooooooossssooo++++o++++/::::------...-:+syyyhhyssoooso+++oo+++/--......````...-:/+osyo/syhyyss+/////:::////-`     
   `ohhhdddddhyso/::-........--:+++++/o+/:``.-:///:/:///+++oo++oossossyyyyyyyyysooo+++++ooossooo+oooo++++o+++/:/::-----....--:/osyyhhyysyyyssosso++:-........``````..-+ysyo+ooyhyso+///////://///-`     
   `+yyhhddhddhs+//:..........-:///+//o//:``-:////:::///+++++o++ooosssyyyyyyyyysssso+oooooooo+oosssoo+++++++/:---.----...-:-.--::+osyysssys++ooo+:-......``..```````..-+sy++ssyyso+/////:/::///:/-`     
   `/shhddddhdyo+//:..........--::////+//-...:///:-:::://////:/+++o+ooossssssyyyyyysooososso+ossyysso++++++/::::-----....-..-:----:/+o++os+/////:-......```````````....-://ooyssoo///////::////::-`     
   `+yhhdhdddhss+//:..........----:/:////-...-:::::::://///:::+///++ooosoooooossssssssooooooosssssso///++/////::-:---.......-..---:-::/++o+::::--.....`..``````````.....-./+oys+//::////:://:/:::-`     
    /shyhhddyyyy+//----..--.-.--..-::://:-`...-:::::::://:::::///+ooooooooooooooossssssoo+oooosssso//+oo+/++/:::::-...---..-...-:--:::/oss++//:---.....```````````.......-o/o///:/::///::///:/:::.`     
    :syyhddhyhhso/:----..--.-..-...---:::-`...---::::////::-:/++oooooooooooooooooosssssssoooosssss++oo+//+///:::::------.--------::////sss+++///----...`.`````````.......:/++/:::::://::////:/::-.      
    .osyhddyhhhhy+/----------........----.`...--:::::::::--://+++oooosssssooooooooosoossssoooooosso+/::++++/:::::::------:--:---:-://+oyysoo++:---.--......```````....`.-:::::::--:/::://///::::-`      
    `/sydhhydmdds//:---------..-......---.`....-:::::::::-://///+++ooooooooooooooooooooooooossooo/++:/oooo+//:///::----::--::-:/:///oosyysso+//:-----.........```....``..-------:--:::://///::--.``     
     .oyhhhhdddh+y/----------...-....---.......-::::::::-::////+++ooooooooooooooooooooooooooooo++oo/+ooos++/+////:::::::::////+//++ossyyssso+///::-:--....-.........````.-.------::::://:///:-..```     
      /shhhyhddhyo:-:::------...--...--.......--::::/::://+//+ooooosssooooo+oooooooooooooooooo+sss+ssooso++/o/+/////////:/+++ooooossyyssooo++/++/+::::-...:--......``````...--.---::::://:::-..````     
      `+yhyyydmds+/+/::------.-----..--........--::::::/++//+++++ooosoooooooo++++oooooooooooosssoossoooooo/++++/+++//////++++o+oooooo++++++ooooo++//:::-::::--....```````....----::::/::::::.``````     
       -oyyyydddyoso/:----::---.---..---........--::///+++++++++ooooo+++oo++o++ooooooooooooooooo+ossssyooo/o+o/+/+++///+oosssyyyyyyyyysooo+oooo+++//::/::::/--...````````....----:-:///-::-.``````      
        -oysyhhdyyyo/:::::::---.-----------......--:///++++++++oo+++/+++//++++++ooooooooo+oo++++ooooossssoosoo+oo++oooossyssyyyyyyyyyysooo+ooo++++////+::-:/--...`````````...----:::////--.```````      
         .osyyhhyhhso+/:::::---------.------.-....--::///+++++++++++/////////+++++++oooooooooooooosssssyyoosoo+oooosooossssssssssssssssoo++ooo+/++///+/:::----..```````````..----:::://:.````````       
          .+ssyhyhhso+:://::-------------------...----:://+//+/+++//::::://///+++++++++++++++++oooooooooo+o+++o+++++ooosooooo++oooooooo++/++++//++/////:-::--...````````````..--::::/::.`````````       
           `:+sysysoo+++/:::-------------------....----:://:///+//:::----::://///////+++++++++++o+oooooo+//++//////+++++++o////+++++++++///+++////////:::---...`````````````..--:::::-.````````         
             `:++sosss+////:.-------------------...-----:::::///::--------::::://///////////++++++++o+++////:::::://///////::::///////////////////:--:---....``````````````..--::::-..````````          
               .+ooooo+++//:----::--------:-----....---:----:::::-----------::::::://////++//////////////:::------::::::-------::::::::::::::::::-:-....```````````````````..--:::-.``````````          
                -+//+o++o++/::::::::---::::---......----------::-------------::::::::://////:::///////::::-----------------------------:::-------.....`````````````````..`...----.```````````           
                 `.:/++oo+///:::::::::::::::--.......---::--------------------------::::::::::////:::::::----.....------.-...........-------........```````````````..........--..````````````           
                   .-/++++++/////::::::::::::-..----.-------::------------------------------::::::------------.......--........................`````````````````````........-...`````````````           
                    `.-/++o+++++//////:::/://:-.------------::---------------------------.--------.----------...................`````......````````````````.........`........```````````````            
                      `-/+++++oo+///+//////////:----::-------:::-----------------------............----------.............`.`..``````..`...````````........................```````````````              
                      `.::/+/+++++osso++++++////::::::::---:::-:::::-::::::-----------...............-.---..............`.`.`..```````````.```````........................````````````````              
                      `..--::/+oyyhhyyssyyso/////////:::::----::::::::::::::::///:::----.............................`.````.``.````````````````....`.``..................``....`...`````                
                      ````..--:/+shyyysyyhys++++++///////:::::::::::-:::::///++++//:::----....---.....--...`........``..```.```````````````````....``...............................```                 
                      `````...-:/ossysossysooooo+++++//+////::://:/:://////++oooo+++/:::::--------...--.............`..```...``````````.``````......................------::::-.---``                   
                       ````..--:/+oossosyysosyhyssssssoooooo+++//:::/+oo/://+osso+++++ooo/://::--------........-...`...``.....``.````````````........-:-:------..-/ossso+++//::-::-``                   
                             `````....---:::://///++++oooosssssss/:++o+::/++oshy//+ssooossoo+/:-----:-.......-.-..................````````....---:::--ooo++///::-osssooo++/:::-..-.```                  
                                           ````````.....----::::///+o/::/+ossyh/:+os+oshhyss++/:::::----.-----.-........-............```...-/::/+++/::+ossoo++/:::---....`````                          
                                                     ````````....-:++-:/+ossyyo//+ososyhyso+oo+//+oosso+/+////::/:::::-:------...........:://o++oo++::osssoo+//:-``                                     
                                                             ````.--:::+oossssooosyyhhdddssyyyhyso++//////////////+++++o++o+oo++++++/////+oososoo++++:+oo++/::--.```                                    
                                                                            ```````...........```````   ``````````````.........................```````````                                              
                                                                                                                                                                                                        
Image courtesy of www.text-image.com and www.petco.com