Parameters:
-i (int): the starting ID
-pl (str): the scripted effect that will revert the law passed by the personal council pending the Elder Council voting
-dl (str): the scripted effect that will implement the desired law if the vote passes

e.g.
-i 1444 -dl ec_increase_resettlement -pl ec_decrease_resettlement
will output:
# Imperial veto
character_event = {
	id = eldercouncil.1444
	desc = {
		text = eldercouncil.1444.advisory
		trigger = {
			has_global_flag = ec_imperial_legislature_advisory
		}
	}
	desc = {
		text = eldercouncil.1444.de_facto
		trigger = {
			has_global_flag = ec_imperial_legislature_de_facto
		}
	}
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	immediate = {
		FROMFROM = {
			save_event_target_as = target_title
			ec_decrease_resettlement = yes
		}
	}

	option = {
		name = eldercouncil.veto
		trigger = {
			block_general_event_trigger = no
		}
		save_event_target_as = target_emperor

		ec_veto_council = yes
		event_target:target_title = {
			ec_increase_resettlement = yes
		}
		elder_council = {
			any_society_member = {
				character_event = { id = eldercouncil.1451 }
			}
		}
		any_realm_lord = {
			limit = {
				top_liege = {
					character = ROOT
				}
				NOT = {
					society_member_of = elder_council
				}
			}
			character_event = { id = eldercouncil.1451 }
		}
		
		ai_chance = {
		    factor = 1
		    ec_veto_default_score = yes
		}
	}

	option = {
		name = eldercouncil.dont_veto

		custom_tooltip = {
			text = elder_council_vote
			hidden_tooltip = {
				elder_council = {
					any_society_member = {
						limit = {
							is_society_grandmaster = yes
						}
						character_event = { id = eldercouncil.1445 }
					}
				}
			}
		}
		
		ai_chance = {
		    factor = 10
		    ec_dont_veto_default_score = yes
		}
	}
}

# High Chancellor ping/notification event - triggered by decision - single desc
character_event = {
	id = eldercouncil.1445
	desc = {
		text = eldercouncil.1445.advise
		trigger = {
			has_global_flag = ec_imperial_legislature_advisory
		}
	}
	desc = {
		text = eldercouncil.1445.ratify
		trigger = {
			has_global_flag = ec_imperial_legislature_de_facto
		}
	}
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	option = {
		name = eldercouncil.hc_accept

		ec_vote_prepare = yes

		hidden_tooltip = {
			elder_council = {
				any_society_member = {
					character_event = { id = eldercouncil.1446 }
				}
			}
			ec_tally_prepare = yes
		}
	}
}

# Councillor votes
character_event = {
	id = eldercouncil.1446
	desc = {
		text = eldercouncil.1446.advise
		trigger = {
			has_global_flag = ec_imperial_legislature_advisory
		}
	}
	desc = {
		text = eldercouncil.1446.ratify
		trigger = {
			has_global_flag = ec_imperial_legislature_de_facto
		}
	}
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	immediate = {
		ec_vote_clr_flag = yes
	}

	option = {
		name = ec_vote_yes

		ec_vote_yes = yes

		ai_chance = {
			factor = 7
			# TODO:JJ
		}
	}

	option = {
		name = ec_vote_no

		ec_vote_no = yes

		ai_chance = {
			factor = 12 # favour status quo
			# TODO:JJ
		}
	}
}

# High Chancellor tallies, breaks tie
character_event = {
	id = eldercouncil.1447

	desc = {
		text = eldercouncil.1447.passed
		trigger = {
			check_variable = { which = ec_votes value > 0 }
		}
	}
	desc = {
		text = eldercouncil.1447.failed
		trigger = {
			check_variable = { which = ec_votes value < 0 }
		}
	}
	desc = {
		text = eldercouncil.1447.tied
		trigger = {
			check_variable = { which = ec_votes value == 0 }
		}
	}

	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	option = {
		name = eldercouncil.passed.accept

		trigger = {
			check_variable = { which = ec_votes value > 0 }
		}

		ec_end_vote = yes
		ec_show_votes = yes

		event_target:target_title = {
			ec_increase_resettlement = yes
		}

		elder_council = {
			any_society_member = {
				limit = {
					NOT = {
						character = ROOT
					}
				}
				character_event = { id = eldercouncil.1448 }
			}
		}

		event_target:target_emperor = {
			character_event = { id = eldercouncil.1448 }
		}
		
	}

	option = {
		name = eldercouncil.failed.accept

		trigger = {
			check_variable = { which = ec_votes value < 0}
		}

		ec_end_vote = yes
		ec_show_votes = yes

		elder_council = {
			any_society_member = {
				limit = {
					NOT = {
						character = ROOT
					}
				}
				character_event = { id = eldercouncil.1449 }
			}
		}


		event_target:target_emperor = {
			character_event = { id = eldercouncil.1449 }
		}
	}

	option = {
		name = eldercouncil.tied.pass

		trigger = {
			check_variable = { which = ec_votes value == 0}
		}

		ec_end_vote = yes
		ec_show_votes = yes

		event_target:target_title = {
			ec_increase_resettlement = yes
		}

		elder_council = {
			any_society_member = {
				limit = {
					NOT = {
						character = ROOT
					}
				}
				character_event = { id = eldercouncil.1448 }
			}
		}

		event_target:target_emperor = {
			character_event = { id = eldercouncil.1448 }
		}

		ai_chance = {
			factor = 1
			modifier = {
				factor = 0
				has_character_flag = ec_vote_no
			}
		}
	}

	option = {
		name = eldercouncil.tied.fail

		trigger = {
			check_variable = { which = ec_votes value == 0}
		}

		ec_end_vote = yes
		ec_show_votes = yes

		elder_council = {
			any_society_member = {
				limit = {
					NOT = {
						character = ROOT
					}
				}
				character_event = { id = eldercouncil.1449 }
			}
		}

		event_target:target_emperor = {
			character_event = { id = eldercouncil.1449 }
		}

		ai_chance = {
			factor = 1
			modifier = {
				factor = 0
				has_character_flag = ec_vote_yes
			}
		}
	}
}

# Vote passes - inform Council
character_event = {
	id = eldercouncil.1448
	desc = {
		text = eldercouncil.1448.passed
		trigger = {
			FROM = {
				check_variable = { which = ec_votes value = 1 }
			}
		}
	}
	desc = {
		text = eldercouncil.1448.tied
		trigger = {
			FROM = {
				is_variable_equal = { which = ec_votes value = 0 }
			}
		}
	}
	desc = {
		text = eldercouncil.1448.error
		trigger = {
			FROM = {
				NOT = {
					check_variable = { which = ec_votes value = 0 }
				}
			}
		}
	}
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	option = {
		name = eldercouncil.very_well
		ec_show_votes = yes
	}
}

# Vote fails - inform Council
character_event = {
	id = eldercouncil.1449
	desc = {
		text = eldercouncil.1449.error
		trigger = {
			FROM = {
				check_variable = { which = ec_votes value = 1 }
			}
		}
	}
	desc = {
		text = eldercouncil.1449.tied
		trigger = {
			FROM = {
				is_variable_equal = { which = ec_votes value = 0 }
			}
		}
	}
	desc = {
		text = eldercouncil.1449.failed
		trigger = {
			FROM = {
				NOT = {
					check_variable = { which = ec_votes value = 0 }
				}
			}
		}
	}
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	option = {
		name = eldercouncil.very_well
		ec_show_votes = yes
		
		ai_chance = {
			factor = 6
			ec_accept_advisement_default_score = yes
		}
	}
	option = {
		name = eldercouncil.ignore_advisement
		trigger = {
			ec_is_emperor = yes
			has_global_flag = ec_imperial_legislature_advisory
		}
		ec_ignore_advisement = yes
		event_target:target_title = {
			ec_increase_resettlement = yes
		}
		elder_council = {
			any_society_member = {
				character_event = { id = eldercouncil.1450 }
			}
		}
		any_realm_lord = {
			limit = {
				top_liege = {
					character = ROOT
				}
				NOT = {
					society_member_of = elder_council
				}
			}
			character_event = { id = eldercouncil.1450 }
		}
		
		ai_chance = {
			factor = 1
			ec_ignore_advisement_default_score = yes
		}
	}
}

# Emperor ignores advisement - inform realm, council
character_event = {
	id = eldercouncil.1450
	desc = eldercouncil.1450.desc
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	option = {
		name = eldercouncil.ignore_react
	}
}

# Emperor vetoes motion - inform realm, council
character_event = {
	id = eldercouncil.1451
	desc = eldercouncil.1451.desc
	picture = GFX_evt_k_eldercouncil

	is_triggered_only = yes

	option = {
		name = eldercouncil.veto_react
	}
}

                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                                                                                                                                                                        
                                                        ``..`..--:/:--...---:--..``                                                                                                                     
                                                   .-::/+oo+oossyysooooooo+++++++++/:-.`                                                                                                                
                                                  `:ossoosssyyyyyyyyysyyssssoo++++ossss+/-.`                                                                                                            
                                                  `-+ooossssyyyyyyyyyyyyyyhyyyyyysssssyyyss+/:-..``                                                                                                     
                                                   .:/+ssssyhhyyyyyyyyyyhhhhhdddddhhhhyysyyyyssss++/:-.`                                                                                                
                                                  `-/osyyhhhyyysyssyyyyyhhhhdddddhysssyyoossyhhyyyysssso+:.`                                                                                            
                                                .:+syyyyyyyysssssssssyyyyyhyhhhddhhhhyyyysossooyhhhhhyyyysso/-`                                                                                         
                                             `-/oyyyyyyyyyssooooosssyyyyyyyyhhhhhhhdddddhhhhhysyhhhhhhhhhyyyys/-```                                                                                     
                                           `:osyyyyyysyyyoooosoooossssyyysyyyhdddddmmmmmdddhhyyydddddddddhhhyyso/:..````````.``````                                                                     
                                         .:+ossssyssysyssooshddhyssssssssssyyyyhdddddmmmdddhhyyddmddddddhhyhhhhhhy+:-.....```..........``                                                               
                                       .:oossssssssssssosssdmhmNdsoooossssssyyyhhdddhhhhdhhhhhhhhddhhddhhyyyhhhhhhys/:---------------.....``````                                                        
                                     .:+oosssssssssssssoooshdmmdhsoooossssssyyyyyyyhhhyyyyhdddddddhhhhhhdhhhhhhhhhhs+/::----------------....-:::..``                                                    
                                   `-+ossssssssssssssssssoooosssooooooosssssyyyyyyyyhhhhhhhhhdddddddhhddddddddhhhhhyo/:::--------------------/ooo+//:.``                                                
                                  ./oosyysssssssssyssyysssoooosssssooossssyyyhhhhhhhhhhhhhhhhhhdddddddhhddddddddhhhys+/:::-:::::::----------:/oossoooo+/:.`                                             
                                 -+o+osyyyyysssssssssssyyysssssyyyyyyyyyyyyyyhhhhhddhhhhhdddddddddddddddddddddddddhyyyo/:------:-----------::://++ossysyys+-`                                           
                                `/+++osssyyyyssssyyyysssssyyyyyyyhhhhhhyyhhhyhhddddddddddddddddddddddddddddddddddddhyyo/-----------------------:/+osssyyyyso/:.`                                        
                                `/+//osssssyyyyyyyyyyssssyyyyyhhhhhhddddhhhhhhhhhhddddddddddddddddddddhhddhhddddhdddhy+/-------:-----------------://osyyyyssoo+:.`                                      
                                 .//+osssssyyyyyyyyyyyyyyyyyyyhhhhdhhddddhhhhhhhddddddddddddddddddddddddhhhhhhhhhhddhys/::----::------------------::/+osyyyyssoo+:`                                     
                                 `:+oshysssyyyyyyysyyysssyyyhhhhhhhhhhddhhhhhhhdhhhhhddddddddhhhdddddddhhhdhhhhhhhdddhy+::----::------------------:::/osyyhhhhyss+/.`                                   
                                 `-/+++ooosyyyyyyyyyyysssssyyyyhhhhhhhhddddddddddhhhhhhdddhhhhhhhddddddhhhdddhhhhhhhhhho/--::------:--------------:::/+osyhhhhhhyys+:`                                  
                                  .:////++ossssyysyyyyysyyyyyhhhhhhhhhhhddddhhdhddhhhhhhhhhhhhhddddddddhhhhhhhhhhhhhdhhs/:---:::::::::-----------://:/+osyyyhhhhhhhyo-`                                 
                                   .:+/////+oosssyyyyyyyyyhhyhhhhhhhhhhhhhddhhddhhhhhhhhhhhhhhhdddddhdddhhhhhhddhhhhdhyo/::---::::::::------------::++osyhhhhhhhhhhyyo/.                                
                                    `-////:://+ossyyyyyyyyyhhhhhhhhhhhhhddddddhhdddhhhhhhhhhhdddddddhdddhhhhhhhhhhhhhyo/:::----:::::::-------------:::+syhhhhhhhhhhhyyyo:`                              
                                      `.-::::///+ssysyyyyyyyyhhhhhhhhhhhhdhddddhdddhhhhhhhhhhhhhhhhdddhhhhhhhhhhhhhhhy+/:::----:::::::------------::::/+shhhhhhhhhhyyyyso/-`                            
                                          ``-:/:::++osssyyyhyyhhhhhhhhdddhdhdddhhhhhdddddddhhhhhhhhddhhhhhhhddhhhdhhhyo/::::--::::::::------------::++++syhhhhhhhyyyyyyyyso:`                           
                                              ``..--:://+oosyyyyhyhhyhhhhddhhhddhhhdddddddddhhddddddddhhhhhdddddhhhyyo//:::::::::::::----------::::/+syyyyhhhhhhhhyyyyyyyhys+.                          
                                                   ```.----::/ossyyyyyyyyhhhhhhdddddddddddddddddddddddddddddddhhyyso+/::::::::::::::----------:::::/+syyhhhhhddhhhhhhyyyyyyyy/`                         
                                                       `-::-:::/osyyyyyyyyyyyhhhhhhhddddddddddddddddddddddddhhyso//:::::::::::::::::----------::://++syhhhhhddddddddhhhhhhhhho:`                        
                                                         `.-:/:://oosssyyyyyyyyhhhhhhhhddddddddddddddhdddhhhyyo+:::::::::::::::::::-----------::/++ossyhhhhdddhhhhhhhhhhhhhhhyo.                        
                                                            ``-:-::://+++oossyssssyyyhyyyhhddddddhdddhddhyo++//:---::::::::::::::::::---------::/+ssshhhhhhhhdhhhhhhhhhhhhhhhhyo.                       
                                                               ``.-::::://///++///+/+++/+oyyyysyssyyhysso/::----------:::://::::::::::-------:::/+yyyhhhhhhhhhhhyyyhhhhhhhhhhhhy+`                      
                                                                  ``.-:/::::::::::::::::://///////////::-------------::::://::/::::::::::::::::/+oyhhhhhhhhhhhhhyyyyyhhhhhhhhhhys/`                     
                                                                     `-//:::::::::::::::::::::::::::----------------:::://////::::::::::::::///+oshdddhhhhhhdddhhhhhhhdddhhhhhhhhs:                     
                                                                      `...------:::::::::::::::::::::-------------:::::////////::::::::::::///++oyhddddhhhhddddddddddddddhhhhhhhhyo.                    
                                                                          `.--::::::::::::/::///://::------------::::://///////:::::::://///+oosyyhhddddddddddddddhdddhhhhhhhhhhhyy/`                   
                                                                           `-::////+++/////////+////::-----------:::://///////////////////++osyhhdddddddddhhhhhhhhhhhhhhhhhhhhhhhhy/`                   
                                                                            `-:///++oooo+++++//++++//::----------::///+/+++////+/////+++ossyyhhhhhhddddddhhhhhhhhyyyyhhhhhhddddhyyo-                    
                                                                             .-/++osyysoo++/:////++++/:----------:///+oooo++++++ooossssyyhhhhhhhhhhhhhhhhhhhhhhhhhhhyyyss+oydhdhsos+-`                  
                                                                             `:+ossyyyso+--.`..-::::::/::-------:/+osyhhyyyyyyyyhddddddhhhhhhhhhhdddddddddddmmmmddhs/:--.``-sdmmdyyys/`                 
                                                                        ``..-/+oosyyyyo/-```````.```.-:/::::--::/+sdmmmmmmmmmmmmmmmmmmmmmddddhhhhhhhhhhhyyyhhhhhyss+/::-..`.:ydddmy/--:.                
                                                                    `.--///ossoosssyyo:``````.`.-://///////+///++syyssssooo+++///////::::::::----......`````````````````````.-/+++/.````                
                                                                   `-.-/+oossooooo/o+:.`````.-:+ooooooosoosyssooo+/:---.......```````````                                                               
                                                                       `````````````        `.//+o++++/+oso+/o/-.``````                                                                                 
                                                                                                         `                                                                                              
                                                                                                                                                                                                        
                                                                                                                                                                                                        
Image courtesy of www.text-image.com and www.immunology.org